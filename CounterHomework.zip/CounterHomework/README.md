# Instance State Exercise

Assignment : Instance State Exercise

## Screenshots
Implementat onSaveIntanceState to save the current state of the app.

### Sebelum di handle
<img src="https://github.com/nuryadincjr/-Instance-State-Exercise/blob/main/img/1.gif" width="233" height="483">

### Setelah di handle

<img src="https://github.com/nuryadincjr/-Instance-State-Exercise/blob/main/img/2.gif" width="233" height="483">

